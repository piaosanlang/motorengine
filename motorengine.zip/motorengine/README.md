motorengine
===========

[![Build Status](https://travis-ci.org/heynemann/motorengine.png?branch=master)](https://travis-ci.org/heynemann/motorengine)
[![PyPi version](https://pypip.in/v/motorengine/badge.png)](https://crate.io/packages/motorengine/)
[![PyPi downloads](https://pypip.in/d/motorengine/badge.png)](https://crate.io/packages/motorengine/)
[![Coverage Status](https://coveralls.io/repos/heynemann/motorengine/badge.png?branch=master)](https://coveralls.io/r/heynemann/motorengine?branch=master)

motorengine is a port of the incredible mongoengine mapper, using Motor for asynchronous access to mongo.

Find out more by reading [motorengine documentation](http://motorengine.readthedocs.org/en/latest/).
